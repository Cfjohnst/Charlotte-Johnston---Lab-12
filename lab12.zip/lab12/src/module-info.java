/**
 * 
 */
/**
 * 
 */
module lab12 {
}